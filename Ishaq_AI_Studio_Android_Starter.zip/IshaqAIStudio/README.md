# Ishaq AI Studio — Android starter

This is the first Android UI prototype for Ishaq AI Studio.

## Included
- Dark branded home screen
- Text-to-video and image-to-video modes
- Photo picker for image-to-video
- Prompt field
- Cinematic, Realistic, Cartoon and 3D style choices
- 9:16, 16:9 and 1:1 format choices
- Create button with prototype status feedback

## Important
This is a starter app, not a finished AI video generator. The interface works, but actual video rendering is not connected yet. A secure backend and an AI video provider/API are required. Keep provider API keys on the backend; never place secret keys inside the Android app.

## Open in Android Studio
1. Unzip the project.
2. Open the `IshaqAIStudio` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Run on an Android phone or emulator.

Package: `com.ishaqaistudio.app`
Minimum Android version: Android 7.0 (API 24)
