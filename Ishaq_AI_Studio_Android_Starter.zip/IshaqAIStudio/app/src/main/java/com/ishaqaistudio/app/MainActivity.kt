package com.ishaqaistudio.app

import android.os.Bundle
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF111827)
private val Violet = Color(0xFF7657F6)
private val SurfaceDark = Color(0xFF1C2333)
private val Muted = Color(0xFF9AA4B7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { StudioScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudioScreen() {
    var prompt by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf("Text to video") }
    var style by remember { mutableStateOf("Cinematic") }
    var ratio by remember { mutableStateOf("9:16") }
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var status by remember { mutableStateOf("Your next video starts with an idea.") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) {
        imageUri = it
        if (it != null) status = "Photo selected. Add a prompt to describe the motion."
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Violet,
            background = Ink,
            surface = SurfaceDark,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("ISHAQ AI STUDIO", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            Text("CREATE • IMAGINE • ANIMATE", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
                        }
                    },
                    actions = {
                        IconButton(onClick = { status = "Projects and account features are coming soon." }) {
                            Icon(Icons.Default.AccountCircle, contentDescription = "Account", tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = SurfaceDark, contentColor = Color.White) {
                    NavigationBarItem(selected = true, onClick = {}, icon = { Icon(Icons.Default.AddCircle, null) }, label = { Text("Create") })
                    NavigationBarItem(selected = false, onClick = { status = "Your saved projects will appear here." }, icon = { Icon(Icons.Default.VideoLibrary, null) }, label = { Text("Projects") })
                    NavigationBarItem(selected = false, onClick = { status = "Settings will be available in a future version." }, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Settings") })
                }
            }
        ) { padding ->
            Column(
                Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("Bring your ideas to life.", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("Create AI videos from text or a photo.", color = Muted, fontSize = 14.sp)
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ModeCard("Text to video", Icons.Default.Edit, mode == "Text to video", Modifier.weight(1f)) { mode = "Text to video" }
                    ModeCard("Image to video", Icons.Default.Image, mode == "Image to video", Modifier.weight(1f)) { mode = "Image to video" }
                }

                Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(18.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(if (mode == "Text to video") "Describe your video" else "Animate a photo", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        if (mode == "Image to video") {
                            OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) {
                                Icon(Icons.Default.AddPhotoAlternate, null)
                                Spacer(Modifier.width(8.dp))
                                Text(if (imageUri == null) "Choose a photo" else "Change selected photo")
                            }
                            if (imageUri != null) Text("Photo selected ✓", color = Color(0xFF7DDBA2), fontSize = 12.sp)
                        }
                        OutlinedTextField(
                            value = prompt,
                            onValueChange = { prompt = it },
                            modifier = Modifier.fillMaxWidth().heightIn(min = 120.dp),
                            placeholder = { Text("Example: A beautiful sunset over Kano city, cinematic camera movement…", color = Muted) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Violet,
                                unfocusedBorderColor = Color(0xFF414B60),
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                cursorColor = Violet
                            )
                        )
                        Text("STYLE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                            listOf("Cinematic", "Realistic", "Cartoon", "3D").forEach { item ->
                                FilterChip(selected = style == item, onClick = { style = item }, label = { Text(item, fontSize = 11.sp) })
                            }
                        }
                        Text("VIDEO FORMAT", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("9:16", "16:9", "1:1").forEach { item ->
                                FilterChip(selected = ratio == item, onClick = { ratio = item }, label = { Text(item) })
                            }
                        }
                        Button(
                            onClick = {
                                status = if (prompt.isBlank()) "Please write a video description first."
                                else if (mode == "Image to video" && imageUri == null) "Please choose a photo first."
                                else "Your project is ready for AI generation. Connect a video AI service to render it."
                            },
                            modifier = Modifier.fillMaxWidth().height(52.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Violet)
                        ) {
                            Icon(Icons.Default.AutoAwesome, null)
                            Spacer(Modifier.width(8.dp))
                            Text("Create video", fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF24213B)), shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, null, tint = Color(0xFFB7A9FF))
                        Spacer(Modifier.width(10.dp))
                        Text(status, color = Color(0xFFE0DCFF), fontSize = 13.sp)
                    }
                }
                Text("AI video generation requires an internet connection and a connected AI provider.", color = Muted, fontSize = 11.sp)
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
fun ModeCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(
        modifier = modifier.clickable(onClick = onClick).border(
            width = if (selected) 1.5.dp else 0.dp,
            color = if (selected) Violet else Color.Transparent,
            shape = RoundedCornerShape(16.dp)
        ),
        colors = CardDefaults.cardColors(containerColor = if (selected) Color(0xFF302957) else SurfaceDark),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, contentDescription = null, tint = if (selected) Color(0xFFC4B8FF) else Muted)
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
        }
    }
}
